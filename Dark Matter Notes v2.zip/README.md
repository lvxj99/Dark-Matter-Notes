<!-- Author: Dongsheng Deng -->
<!-- Email: ddswhu@outlook.com -->

# ElegantNote

[Homepage](https://elegantlatex.org/) | [Github](https://github.com/ElegantLaTeX/ElegantNote) | [CTAN](https://ctan.org/pkg/elegantnote) | [Download](https://github.com/ElegantLaTeX/ElegantNote/releases) | [Wiki](https://github.com/ElegantLaTeX/ElegantNote/wiki) | [Weibo](https://weibo.com/elegantlatex)

![License](https://img.shields.io/ctan/l/elegantnote.svg)
![CTAN Version](https://img.shields.io/ctan/v/elegantnote.svg)
![Github Version](https://img.shields.io/github/release/ElegantLaTeX/ElegantNote.svg)
![Repo Size](https://img.shields.io/github/repo-size/ElegantLaTeX/ElegantNote.svg)

ElegantNote is designed for Notes. Just enjoy it! If you have any questions, suggestions or bug reports, you can create issues, pull requests or email us at elegantlatex2e@gmail.com.

设计 ElegantNote 是为了方便记录笔记和阅读笔记。如果你有其他问题、建议或者报告 bug，可以提交 issues 或者给我们发邮件：elegantlatex2e@gmail.com。最近我们新建了一个 QQ 用户交流群（Q 群：692108391），欢迎加入。

# License

This work is released under the LaTeX Project Public License, v1.3c or later. 

本模板发布遵循 LaTeX 项目公共许可证 1.3 c 或更高版本。
